/*Java Class
A class is a blueprint for the object. Before we create an object, we first need to define the class.

We can think of the class as a sketch (prototype) of a house. It contains all the details about the floors, doors, windows, etc. Based on these descriptions we build the house. House is the object.

Since many houses can be made from the same description, we can create many objects from a class.

java is an object-oriented programming language. The core concept of the object-oriented approach is to break complex problems into smaller objects.

An object is any entity that has a state and behavior. For example, a bicycle is an object. It has

States: idle, first gear, etc
Behaviors: braking, accelerating, etc.

*/

class Cat {
	boolean hasfur;
	String color, breed;
	int legs, eyes;

	public void eat() {
		System.out.println("cat is eating");

	}

	public void walk() {
		System.out.println("cat is walking");
	}

	public void description() {
		System.out.println("my cat has "+legs+" legs & "+eyes+" eyes");
	}
}

class Person {
	String name;
	int age;

}

public class Main {
  public static void main(String[] args) {
    
		Cat cat1 = new Cat();
		Cat cat2 = new Cat();

		cat1.legs = 3;
		cat1.eyes = 2;

		cat2.legs = 4;
		cat2.eyes = 2;

		cat1.walk();
		cat1.eat();
		cat2.eat();
		cat1.description();
		cat2.description();
  }
}